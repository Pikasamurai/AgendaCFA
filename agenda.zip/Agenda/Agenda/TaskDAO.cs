﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public class TaskDAO : DAO

    {
      

        public TaskDAO() : base()
        {
            
        }

        public override Object create(Object obj)
        {
            TaskModel task = (TaskModel)obj;

            return task;
        }

        public override void delete(Object obj)
        {
            
        }
        public override void update(Object obj)
        {
           
        }

        public override Object find(Object obj)
        {
            TaskModel task = (TaskModel)obj;
            UserModel user = new UserModel();
           

            try
            {
                string request = "SELECT * from task WHERE id_taskuser_fk= 1";
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);
                MySqlDataReader dataReader = command.ExecuteReader();
                
                while (dataReader.Read())
                {
                    string name_task_reader = dataReader.GetValue(1).ToString();
                    string comment_task_reader = dataReader.GetValue(2).ToString(); ;
                    string date_task_reader = dataReader.GetValue(3).ToString();
                    user.List_task.Add(new TaskModel() {Name_task = name_task_reader, Comment_task = comment_task_reader, Date_task = date_task_reader });                    
                }
            
                dataReader.Close();

            }
            catch(MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }
            return user.List_task;
        }

        

    
    }
}

