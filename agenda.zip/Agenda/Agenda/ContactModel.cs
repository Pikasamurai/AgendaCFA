﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    class ContactModel
    {
        private int id_contact;
        private int id_contactuser_fk;
        private string name_contact;
        private string adress_contact;
        private string phone_contact;

       

        public ContactModel()
        {
            this.id_contact = 0;
            this.id_contactuser_fk = 0;
            this.name_contact = "";
            this.adress_contact = "";
            this.phone_contact = "";
        }

        public ContactModel(int id_contact, int id_contactuser_fk, string name_contact, string adress_contact, string phone_contact)
        {
            this.id_contact = id_contact;
            this.id_contactuser_fk = id_contactuser_fk;
            this.name_contact = name_contact;
            this.adress_contact = adress_contact;
            this.phone_contact = phone_contact;
        }


        public int Id_contact { get => id_contact; set => id_contact = value; }
        public int Id_contactuser_fk { get => id_contactuser_fk; set => id_contactuser_fk = value; }
        public string Name_contact { get => name_contact; set => name_contact = value; }
        public string Adress_contact { get => adress_contact; set => adress_contact = value; }
        public string Phone_contact { get => phone_contact; set => phone_contact = value; }
    }
}
