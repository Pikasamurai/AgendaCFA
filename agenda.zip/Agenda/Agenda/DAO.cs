﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    public abstract class DAO
    {
        private ConnectionBdd connect = null;

        internal ConnectionBdd Connect { get => connect; set => connect = value; }

        public DAO()
        {
            this.connect = ConnectionBdd.getInstance(); 
        }

        public abstract Object create(Object obj);

        public abstract void delete(Object obj);

        public abstract void update(Object obj);

        public abstract Object find(Object obj); 

       
    }
}
