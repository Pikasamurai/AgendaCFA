﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    class UserModel
    {
        private int id_user;
        private string name_user;
        private string password;
        private List<TaskModel> list_task;
        private List<NoteModel> list_note;
        private List<ContactModel> list_contact;

        public UserModel()
        {
            this.id_user = 0;
            this.name_user = "";
            this.password = "";
            this.list_task = new List<TaskModel>();
            this.list_note = new List<NoteModel>();
            this.list_contact = new List<ContactModel>();
        }

        public UserModel(int id_user, string name_user, string password)
        {
            this.id_user = id_user;
            this.name_user = name_user;
            this.password = password;
        }

        public UserModel(string name_user, string password)
        {
           
            this.name_user = name_user;
            this.password = password;
        }

        public UserModel(int id_user)
        {

            this.id_user = id_user;
        }





        public int Id_user { get => id_user; set => id_user = value; }
        public string Name_user { get => name_user; set => name_user = value; }
        public string Password { get => password; set => password = value; }
        public List<TaskModel> List_task { get => list_task; set => list_task = value; }
        public List<NoteModel> List_note { get => list_note; set => list_note = value; }
        public List<ContactModel> List_contact { get => list_contact; set => list_contact = value; }

        //add a task to a user
        public void AddTask(TaskModel task)
        {
            if (!this.list_task.Contains(task))
                this.list_task.Add(task);
        }

        //remove a task to a user
        public void RemoveTask(TaskModel task)
        {
            this.list_task.Remove(task);
        }
        //add a note to a user 
        public void AddNote(NoteModel note)
        {
            if (!this.list_note.Contains(note))
                this.list_note.Add(note);
        }
        //remove a note to a user 
        public void RemoveNote(NoteModel note)
        {
            this.list_note.Remove(note);
        }
        //add a contact to a user 
        public void AddContact(ContactModel contact)
        {
            if (!this.list_contact.Contains(contact))
                this.list_contact.Add(contact);
        }
        //remove a contact to a user
        public void RemoveContact(ContactModel contact)
        {
            this.list_contact.Remove(contact);
        }

        

    }
}
