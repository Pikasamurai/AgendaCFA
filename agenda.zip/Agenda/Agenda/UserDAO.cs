﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public class UserDAO: DAO
    {
 
        public UserDAO() : base()
        {

        }

        public override Object create(Object obj)
        {
            UserModel user = (UserModel)obj;
            try
            {

               
                string request = "INSERT INTO username (id_user, name_user, password) VALUES (@id_user , @name_user , @password)";
                MySqlCommand command = new MySqlCommand(request,this.Connect.Bdd);

                command.Parameters.Add("@id_user", MySqlDbType.Int32);
                command.Parameters.Add("@name_user", MySqlDbType.VarChar);
                command.Parameters.Add("@password", MySqlDbType.VarChar);

                command.Parameters["@id_user"].Value = null;
                command.Parameters["@name_user"].Value = user.Name_user;
                command.Parameters["@password"].Value = user.Password;

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Utilisateur bien ajouté");
                dataReader.Close();
   
                
            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return user;
            
        }

        public override void delete(Object obj)
        {
            
        }
        public override void update(Object obj)
        {

            
        }

        public override Object find(Object obj)
        {
            UserModel user = new UserModel();
            //UserModel user = (UserModel)obj;
            string request = "SELECT id_user FROM username WHERE name_user= @name_user AND password= @password";
            try
            {
                
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

           
                command.Parameters.Add("@name_user", MySqlDbType.VarChar);
                command.Parameters.Add("@password", MySqlDbType.VarChar);

         
                command.Parameters["@name_user"].Value = user.Name_user;
                command.Parameters["@password"].Value = user.Password;

                MySqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    user.Id_user = Convert.ToInt32(dataReader.GetValue(0));
                }
               
          
                MessageBox.Show("Bonjour " + user.Name_user);

                dataReader.Close();


            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }

            return user;

        }




    }
}
