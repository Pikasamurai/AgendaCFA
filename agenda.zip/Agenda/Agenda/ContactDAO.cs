﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Agenda
//{
//    public class ContactDAO<ContactModel> : DAO<ContactModel>

//    {

//        public ContactDAO() : base()
//        {

//        }

//        public override bool create(ContactModel obj)
//        {
//            return false;
//        }

//        public override bool delete(ContactModel obj)
//        {
//            return false;
//        }
//        public override bool update(ContactModel obj)
//        {
//            return false;
//        }

//        public override ContactModel find(int id)
//        {
//            ContactModel task;

 
//        }




//    }
//}
