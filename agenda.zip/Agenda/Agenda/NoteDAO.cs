﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Agenda
//{
//    public class NoteDAO<NoteModel> : DAO<NoteModel>

//    {

//        public NoteDAO() : base()
//        {

//        }

//        public override bool create(NoteModel obj)
//        {
//            return false;
//        }

//        public override bool delete(NoteModel obj)
//        {
//            return false;
//        }
//        public override bool update(NoteModel obj)
//        {
//            return false;
//        }

//        public override NoteModel find(int id)
//        {
//            NoteModel note;
    
//        }




//    }
//}
