﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    //singleton
        sealed class ConnectionBdd
        {
        private string connectionString; 
        private static ConnectionBdd instance;
        private MySqlConnection bdd;

        private ConnectionBdd()
        {
            connectionString = "Server=127.0.0.1;Database=bdd_agendatest;port=3306;User Id=root;password=";
            try
            {
                bdd = new MySqlConnection(connectionString);

                bdd.Open();
              
            }

            catch (MySql.Data.MySqlClient.MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }


        }

        public MySqlConnection Bdd { get => bdd; set => bdd = value; }

        public static ConnectionBdd getInstance()
        {
            if (instance == null)
            {
                instance = new ConnectionBdd();
            }

            return instance;
        }
        


    }
}
