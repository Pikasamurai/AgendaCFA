﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public class TaskDAO : DAO

    {
        public TaskDAO() : base()
        {

        }

        //Méthode DAO de création de tâche
        public override Object create(Object obj)
        {
            TaskModel task = (TaskModel)obj;

            try
            {
                string request = "INSERT INTO task (id_task,id_taskuser_fk,name_task,comment_task,date_task) VALUES " +
                    "(@id_task, @id_taskuser_fk, @name_task, @comment_task, @date_task)";

                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                command.Parameters.Add("@id_task", MySqlDbType.Int32);
                command.Parameters.Add("@id_taskuser_fk", MySqlDbType.Int32);
                command.Parameters.Add("@name_task", MySqlDbType.VarChar);
                command.Parameters.Add("@comment_task", MySqlDbType.VarChar);
                command.Parameters.Add("@date_task", MySqlDbType.DateTime);

                command.Parameters["@id_task"].Value = null;
                command.Parameters["@id_taskuser_fk"].Value = task.Id_taskuser_fk;
                command.Parameters["@name_task"].Value = task.Name_task;
                command.Parameters["@comment_task"].Value = task.Comment_task;
                command.Parameters["@date_task"].Value = DateTime.Now;

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Tâche bien ajouté");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return task;
        }

        //Méthode DAO de suppression de tâche
        public override Object delete(Object obj)
        {
            TaskModel task = (TaskModel)obj;

            try
            {
                string request = "DELETE FROM task WHERE id_task =" + task.Id_task;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre tâche à bien été supprimé");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return task;
        }

        //Méthode DAO de modification de tâche
        public override Object update(Object obj)
        {
            TaskModel task = (TaskModel)obj;

            try
            {
                string request = "UPDATE task SET name_task = @New_name_task, comment_task = @New_comment_task" +
                    " WHERE id_task = " + task.Id_task;

                //pas oublié d'ajouter date_task = @New_date_task dans request

                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);


                command.Parameters.Add("@New_name_task", MySqlDbType.VarChar);
                command.Parameters.Add("@New_comment_task", MySqlDbType.VarChar);
                //command.Parameters.Add("@New_date_task", MySqlDbType.VarChar);


                command.Parameters["@New_name_task"].Value = task.Name_task;
                command.Parameters["@New_comment_task"].Value = task.Comment_task;
                //command.Parameters["@New_date_task"].Value = task.Date_task;

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre tâche a bien été modifiée");
                dataReader.Close();

            }
            catch (MySqlException exc)

            {
                MessageBox.Show(exc.ToString());
            }

            return task;
        }

        //Méthode DAO de recherche de tâche
        public override Object find(Object obj)
        {
            TaskModel task = (TaskModel)obj;
            UserModel user = new UserModel();
            try
            {
                string request = "SELECT * from task WHERE id_taskuser_fk = " + task.Id_taskuser_fk;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);
                MySqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int id_task_reader = Convert.ToInt32(dataReader.GetValue(0));
                    string name_task_reader = dataReader.GetValue(2).ToString();
                    string comment_task_reader = dataReader.GetValue(3).ToString();
                    string date_task_reader = dataReader.GetValue(4).ToString();
                    user.List_task.Add(new TaskModel() { Id_task = id_task_reader, Name_task = name_task_reader, Comment_task = comment_task_reader, Date_task = date_task_reader });
                }

                dataReader.Close();
            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }
            return user.List_task;
        }

    }
}

