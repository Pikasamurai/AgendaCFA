﻿using System;

namespace Agenda
{
    partial class FormAddTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonAddTaskConfirm = new System.Windows.Forms.Button();
            this.ButtonAddTaskCancel = new System.Windows.Forms.Button();
            this.LabelAddTaskName = new System.Windows.Forms.Label();
            this.LabelAddTaskDate = new System.Windows.Forms.Label();
            this.TextBoxAddTaskName = new System.Windows.Forms.TextBox();
            this.TextBoxAddTaskDate = new System.Windows.Forms.TextBox();
            this.TextBoxAddTaskComment = new System.Windows.Forms.TextBox();
            this.LabelAddTaskComment = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ButtonAddTaskConfirm
            // 
            this.ButtonAddTaskConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddTaskConfirm.Location = new System.Drawing.Point(97, 191);
            this.ButtonAddTaskConfirm.Name = "ButtonAddTaskConfirm";
            this.ButtonAddTaskConfirm.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddTaskConfirm.TabIndex = 0;
            this.ButtonAddTaskConfirm.Text = "Confirmer";
            this.ButtonAddTaskConfirm.UseVisualStyleBackColor = true;
            this.ButtonAddTaskConfirm.Click += new System.EventHandler(this.ButtonAddTaskConfirm_Click);
            // 
            // ButtonAddTaskCancel
            // 
            this.ButtonAddTaskCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddTaskCancel.Location = new System.Drawing.Point(181, 191);
            this.ButtonAddTaskCancel.Name = "ButtonAddTaskCancel";
            this.ButtonAddTaskCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddTaskCancel.TabIndex = 1;
            this.ButtonAddTaskCancel.Text = "Annuler";
            this.ButtonAddTaskCancel.UseVisualStyleBackColor = true;
            this.ButtonAddTaskCancel.Click += new System.EventHandler(this.ButtonAddTaskCancel_Click);
            // 
            // LabelAddTaskName
            // 
            this.LabelAddTaskName.Location = new System.Drawing.Point(12, 9);
            this.LabelAddTaskName.Name = "LabelAddTaskName";
            this.LabelAddTaskName.Size = new System.Drawing.Size(100, 20);
            this.LabelAddTaskName.TabIndex = 2;
            this.LabelAddTaskName.Text = "Nom";
            this.LabelAddTaskName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddTaskDate
            // 
            this.LabelAddTaskDate.Location = new System.Drawing.Point(12, 35);
            this.LabelAddTaskDate.Name = "LabelAddTaskDate";
            this.LabelAddTaskDate.Size = new System.Drawing.Size(100, 20);
            this.LabelAddTaskDate.TabIndex = 3;
            this.LabelAddTaskDate.Text = "Date";
            this.LabelAddTaskDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddTaskComment
            // 
            this.LabelAddTaskComment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelAddTaskComment.Location = new System.Drawing.Point(12, 64);
            this.LabelAddTaskComment.Name = "LabelAddTaskComment";
            this.LabelAddTaskComment.Size = new System.Drawing.Size(100, 20);
            this.LabelAddTaskComment.TabIndex = 9;
            this.LabelAddTaskComment.Text = "Commentaire";
            // 
            // TextBoxAddTaskName
            // 
            this.TextBoxAddTaskName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddTaskName.Location = new System.Drawing.Point(118, 9);
            this.TextBoxAddTaskName.Name = "TextBoxAddTaskName";
            this.TextBoxAddTaskName.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddTaskName.TabIndex = 5;
            // 
            // TextBoxAddTaskDate
            // 
            this.TextBoxAddTaskDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddTaskDate.Location = new System.Drawing.Point(118, 35);
            this.TextBoxAddTaskDate.Name = "TextBoxAddTaskDate";
            this.TextBoxAddTaskDate.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddTaskDate.TabIndex = 6;
            // 
            // TextBoxAddTaskComment
            // 
            this.TextBoxAddTaskComment.Location = new System.Drawing.Point(12, 87);
            this.TextBoxAddTaskComment.Multiline = true;
            this.TextBoxAddTaskComment.Name = "TextBoxAddTaskComment";
            this.TextBoxAddTaskComment.Size = new System.Drawing.Size(233, 98);
            this.TextBoxAddTaskComment.TabIndex = 8;
            // 
            // FormAddTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 226);
            this.Controls.Add(this.LabelAddTaskComment);
            this.Controls.Add(this.TextBoxAddTaskComment);
            this.Controls.Add(this.TextBoxAddTaskDate);
            this.Controls.Add(this.TextBoxAddTaskName);
            this.Controls.Add(this.LabelAddTaskDate);
            this.Controls.Add(this.LabelAddTaskName);
            this.Controls.Add(this.ButtonAddTaskCancel);
            this.Controls.Add(this.ButtonAddTaskConfirm);
            this.Name = "FormAddTask";
            this.Text = "Ajouter une tâche";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAddTaskConfirm;
        private System.Windows.Forms.Button ButtonAddTaskCancel;
        private System.Windows.Forms.Label LabelAddTaskName;
        private System.Windows.Forms.Label LabelAddTaskDate;
        private System.Windows.Forms.Label LabelAddTaskComment;
        private System.Windows.Forms.TextBox TextBoxAddTaskName;
        private System.Windows.Forms.TextBox TextBoxAddTaskDate;
        private System.Windows.Forms.TextBox TextBoxAddTaskComment;
    }
}