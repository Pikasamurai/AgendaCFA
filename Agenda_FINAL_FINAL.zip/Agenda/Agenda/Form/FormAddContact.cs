﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class FormAddContact : Form
    {
        public FormAddContact()
        {
            InitializeComponent();
        }

        private Form2 form2;

        public Form2 Form2 { get => form2; set => form2 = value; }

        //Méthodes d'annulation & de confirmation d'ajout de contact
        private void ButtonAddContactCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonAddContactConfirm_Click(object sender, EventArgs e)
        {
            ContactDAO contactdao = new ContactDAO();
            ContactModel contact = (ContactModel)contactdao.create(new ContactModel(DAO.Id_sess, TextBoxAddContactName.Text, TextBoxAddContactAdress.Text, TextBoxAddContactPhone.Text));
            form2.refresh();
        }
    }
}
