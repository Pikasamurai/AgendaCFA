﻿using System;

namespace MysqlContact
{
    partial class FormAddNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonAddNoteConfirm = new System.Windows.Forms.Button();
            this.ButtonAddNoteCancel = new System.Windows.Forms.Button();
            this.LabelAddNoteName = new System.Windows.Forms.Label();
            this.LabelAddNoteAdress = new System.Windows.Forms.Label();
            this.LabelAddNotePhone = new System.Windows.Forms.Label();
            this.TextBoxAddNoteName = new System.Windows.Forms.TextBox();
            this.TextBoxAddNoteAdress = new System.Windows.Forms.TextBox();
            this.TextBoxAddNotePhone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ButtonAddNoteConfirm
            // 
            this.ButtonAddNoteConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddNoteConfirm.Location = new System.Drawing.Point(97, 99);
            this.ButtonAddNoteConfirm.Name = "ButtonAddNoteConfirm";
            this.ButtonAddNoteConfirm.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddNoteConfirm.TabIndex = 0;
            this.ButtonAddNoteConfirm.Text = "Confirmer";
            this.ButtonAddNoteConfirm.UseVisualStyleBackColor = true;
            this.ButtonAddNoteConfirm.Click += new System.EventHandler(ButtonAddNoteConfirm_Click);

            // 
            // ButtonAddNoteCancel
            // 
            this.ButtonAddNoteCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddNoteCancel.Location = new System.Drawing.Point(181, 99);
            this.ButtonAddNoteCancel.Name = "ButtonAddNoteCancel";
            this.ButtonAddNoteCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddNoteCancel.TabIndex = 1;
            this.ButtonAddNoteCancel.Text = "Annuler";
            this.ButtonAddNoteCancel.UseVisualStyleBackColor = true;
            this.ButtonAddNoteCancel.Click += new System.EventHandler(ButtonAddNoteCancel_Click);
            // 
            // LabelAddNoteName
            // 
            this.LabelAddNoteName.Location = new System.Drawing.Point(12, 9);
            this.LabelAddNoteName.Name = "LabelAddNoteName";
            this.LabelAddNoteName.Size = new System.Drawing.Size(100, 20);
            this.LabelAddNoteName.TabIndex = 2;
            this.LabelAddNoteName.Text = "Nom";
            this.LabelAddNoteName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddNoteAdress
            // 
            this.LabelAddNoteAdress.Location = new System.Drawing.Point(12, 35);
            this.LabelAddNoteAdress.Name = "LabelAddNoteAdress";
            this.LabelAddNoteAdress.Size = new System.Drawing.Size(100, 20);
            this.LabelAddNoteAdress.TabIndex = 3;
            this.LabelAddNoteAdress.Text = "Adresse";
            this.LabelAddNoteAdress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddNotePhone
            // 
            this.LabelAddNotePhone.AutoSize = true;
            this.LabelAddNotePhone.Location = new System.Drawing.Point(12, 65);
            this.LabelAddNotePhone.Name = "LabelAddNotePhone";
            this.LabelAddNotePhone.Size = new System.Drawing.Size(58, 13);
            this.LabelAddNotePhone.TabIndex = 4;
            this.LabelAddNotePhone.Text = "Téléphone";
            this.LabelAddNotePhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxAddNoteName
            // 
            this.TextBoxAddNoteName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddNoteName.Location = new System.Drawing.Point(118, 9);
            this.TextBoxAddNoteName.Name = "TextBoxAddNoteName";
            this.TextBoxAddNoteName.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddNoteName.TabIndex = 5;
            // 
            // TextBoxAddNoteAdress
            // 
            this.TextBoxAddNoteAdress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddNoteAdress.Location = new System.Drawing.Point(118, 35);
            this.TextBoxAddNoteAdress.Name = "TextBoxAddNoteAdress";
            this.TextBoxAddNoteAdress.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddNoteAdress.TabIndex = 6;
            // 
            // TextBoxAddNotePhone
            // 
            this.TextBoxAddNotePhone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddNotePhone.Location = new System.Drawing.Point(118, 61);
            this.TextBoxAddNotePhone.Name = "TextBoxAddNotePhone";
            this.TextBoxAddNotePhone.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddNotePhone.TabIndex = 7;
            // 
            // FormAddNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 134);
            this.Controls.Add(this.TextBoxAddNotePhone);
            this.Controls.Add(this.TextBoxAddNoteAdress);
            this.Controls.Add(this.TextBoxAddNoteName);
            this.Controls.Add(this.LabelAddNotePhone);
            this.Controls.Add(this.LabelAddNoteAdress);
            this.Controls.Add(this.LabelAddNoteName);
            this.Controls.Add(this.ButtonAddNoteCancel);
            this.Controls.Add(this.ButtonAddNoteConfirm);
            this.Name = "FormAddNote";
            this.Text = "Ajouter une note";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAddNoteConfirm;
        private System.Windows.Forms.Button ButtonAddNoteCancel;
        private System.Windows.Forms.Label LabelAddNoteName;
        private System.Windows.Forms.Label LabelAddNoteAdress;
        private System.Windows.Forms.Label LabelAddNotePhone;
        private System.Windows.Forms.TextBox TextBoxAddNoteName;
        private System.Windows.Forms.TextBox TextBoxAddNoteAdress;
        private System.Windows.Forms.TextBox TextBoxAddNotePhone;
    }
}