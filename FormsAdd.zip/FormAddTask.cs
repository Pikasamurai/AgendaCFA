﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MysqlContact
{
    public partial class FormAddTask : Form
    {
        public FormAddTask()
        {
            InitializeComponent();
        }


        private void ButtonAddTaskConfirm_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void ButtonAddTaskCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
