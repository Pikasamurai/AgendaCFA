﻿using System;

namespace MysqlContact
{
    partial class FormAddTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonAddTaskConfirm = new System.Windows.Forms.Button();
            this.ButtonAddTaskCancel = new System.Windows.Forms.Button();
            this.LabelAddTaskName = new System.Windows.Forms.Label();
            this.LabelAddTaskAdress = new System.Windows.Forms.Label();
            this.LabelAddTaskPhone = new System.Windows.Forms.Label();
            this.TextBoxAddTaskName = new System.Windows.Forms.TextBox();
            this.TextBoxAddTaskAdress = new System.Windows.Forms.TextBox();
            this.TextBoxAddTaskPhone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ButtonAddTaskConfirm
            // 
            this.ButtonAddTaskConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddTaskConfirm.Location = new System.Drawing.Point(97, 99);
            this.ButtonAddTaskConfirm.Name = "ButtonAddTaskConfirm";
            this.ButtonAddTaskConfirm.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddTaskConfirm.TabIndex = 0;
            this.ButtonAddTaskConfirm.Text = "Confirmer";
            this.ButtonAddTaskConfirm.UseVisualStyleBackColor = true;
            this.ButtonAddTaskConfirm.Click += new System.EventHandler(ButtonAddTaskConfirm_Click);
            // 
            // ButtonAddTaskCancel
            // 
            this.ButtonAddTaskCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddTaskCancel.Location = new System.Drawing.Point(181, 99);
            this.ButtonAddTaskCancel.Name = "ButtonAddTaskCancel";
            this.ButtonAddTaskCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddTaskCancel.TabIndex = 1;
            this.ButtonAddTaskCancel.Text = "Annuler";
            this.ButtonAddTaskCancel.UseVisualStyleBackColor = true;
            this.ButtonAddTaskCancel.Click += new System.EventHandler(ButtonAddTaskCancel_Click);
            // 
            // LabelAddTaskName
            // 
            this.LabelAddTaskName.Location = new System.Drawing.Point(12, 9);
            this.LabelAddTaskName.Name = "LabelAddTaskName";
            this.LabelAddTaskName.Size = new System.Drawing.Size(100, 20);
            this.LabelAddTaskName.TabIndex = 2;
            this.LabelAddTaskName.Text = "Nom";
            this.LabelAddTaskName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddTaskAdress
            // 
            this.LabelAddTaskAdress.Location = new System.Drawing.Point(12, 35);
            this.LabelAddTaskAdress.Name = "LabelAddTaskAdress";
            this.LabelAddTaskAdress.Size = new System.Drawing.Size(100, 20);
            this.LabelAddTaskAdress.TabIndex = 3;
            this.LabelAddTaskAdress.Text = "Adresse";
            this.LabelAddTaskAdress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddTaskPhone
            // 
            this.LabelAddTaskPhone.AutoSize = true;
            this.LabelAddTaskPhone.Location = new System.Drawing.Point(12, 65);
            this.LabelAddTaskPhone.Name = "LabelAddTaskPhone";
            this.LabelAddTaskPhone.Size = new System.Drawing.Size(58, 13);
            this.LabelAddTaskPhone.TabIndex = 4;
            this.LabelAddTaskPhone.Text = "Téléphone";
            this.LabelAddTaskPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxAddTaskName
            // 
            this.TextBoxAddTaskName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddTaskName.Location = new System.Drawing.Point(118, 9);
            this.TextBoxAddTaskName.Name = "TextBoxAddTaskName";
            this.TextBoxAddTaskName.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddTaskName.TabIndex = 5;
            // 
            // TextBoxAddTaskAdress
            // 
            this.TextBoxAddTaskAdress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddTaskAdress.Location = new System.Drawing.Point(118, 35);
            this.TextBoxAddTaskAdress.Name = "TextBoxAddTaskAdress";
            this.TextBoxAddTaskAdress.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddTaskAdress.TabIndex = 6;
            // 
            // TextBoxAddTaskPhone
            // 
            this.TextBoxAddTaskPhone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddTaskPhone.Location = new System.Drawing.Point(118, 61);
            this.TextBoxAddTaskPhone.Name = "TextBoxAddTaskPhone";
            this.TextBoxAddTaskPhone.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddTaskPhone.TabIndex = 7;
            // 
            // FormAddTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 134);
            this.Controls.Add(this.TextBoxAddTaskPhone);
            this.Controls.Add(this.TextBoxAddTaskAdress);
            this.Controls.Add(this.TextBoxAddTaskName);
            this.Controls.Add(this.LabelAddTaskPhone);
            this.Controls.Add(this.LabelAddTaskAdress);
            this.Controls.Add(this.LabelAddTaskName);
            this.Controls.Add(this.ButtonAddTaskCancel);
            this.Controls.Add(this.ButtonAddTaskConfirm);
            this.Name = "FormAddTask";
            this.Text = "Ajouter une tâche";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAddTaskConfirm;
        private System.Windows.Forms.Button ButtonAddTaskCancel;
        private System.Windows.Forms.Label LabelAddTaskName;
        private System.Windows.Forms.Label LabelAddTaskAdress;
        private System.Windows.Forms.Label LabelAddTaskPhone;
        private System.Windows.Forms.TextBox TextBoxAddTaskName;
        private System.Windows.Forms.TextBox TextBoxAddTaskAdress;
        private System.Windows.Forms.TextBox TextBoxAddTaskPhone;
    }
}