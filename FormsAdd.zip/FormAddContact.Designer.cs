﻿namespace MysqlContact
{
    partial class FormAddContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonAddContactConfirm = new System.Windows.Forms.Button();
            this.ButtonAddContactCancel = new System.Windows.Forms.Button();
            this.LabelAddContactName = new System.Windows.Forms.Label();
            this.LabelAddContactAdress = new System.Windows.Forms.Label();
            this.LabelAddContactPhone = new System.Windows.Forms.Label();
            this.TextBoxAddContactName = new System.Windows.Forms.TextBox();
            this.TextBoxAddContactAdress = new System.Windows.Forms.TextBox();
            this.TextBoxAddContactPhone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ButtonAddContactConfirm
            // 
            this.ButtonAddContactConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddContactConfirm.Location = new System.Drawing.Point(97, 99);
            this.ButtonAddContactConfirm.Name = "ButtonAddContactConfirm";
            this.ButtonAddContactConfirm.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddContactConfirm.TabIndex = 0;
            this.ButtonAddContactConfirm.Text = "Confirmer";
            this.ButtonAddContactConfirm.UseVisualStyleBackColor = true;
            this.ButtonAddContactConfirm.Click += new System.EventHandler(ButtonAddContactConfirm_Click);
            // 
            // ButtonAddContactCancel
            // 
            this.ButtonAddContactCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddContactCancel.Location = new System.Drawing.Point(181, 99);
            this.ButtonAddContactCancel.Name = "ButtonAddContactCancel";
            this.ButtonAddContactCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddContactCancel.TabIndex = 1;
            this.ButtonAddContactCancel.Text = "Annuler";
            this.ButtonAddContactCancel.UseVisualStyleBackColor = true;
            this.ButtonAddContactCancel.Click += new System.EventHandler(ButtonAddContactCancel_Click);
            // 
            // LabelAddContactName
            // 
            this.LabelAddContactName.Location = new System.Drawing.Point(12, 9);
            this.LabelAddContactName.Name = "LabelAddContactName";
            this.LabelAddContactName.Size = new System.Drawing.Size(100, 20);
            this.LabelAddContactName.TabIndex = 2;
            this.LabelAddContactName.Text = "Nom";
            this.LabelAddContactName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddContactAdress
            // 
            this.LabelAddContactAdress.Location = new System.Drawing.Point(12, 35);
            this.LabelAddContactAdress.Name = "LabelAddContactAdress";
            this.LabelAddContactAdress.Size = new System.Drawing.Size(100, 20);
            this.LabelAddContactAdress.TabIndex = 3;
            this.LabelAddContactAdress.Text = "Adresse";
            this.LabelAddContactAdress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LabelAddContactPhone
            // 
            this.LabelAddContactPhone.AutoSize = true;
            this.LabelAddContactPhone.Location = new System.Drawing.Point(12, 65);
            this.LabelAddContactPhone.Name = "LabelAddContactPhone";
            this.LabelAddContactPhone.Size = new System.Drawing.Size(58, 13);
            this.LabelAddContactPhone.TabIndex = 4;
            this.LabelAddContactPhone.Text = "Téléphone";
            this.LabelAddContactPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxAddContactName
            // 
            this.TextBoxAddContactName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddContactName.Location = new System.Drawing.Point(118, 9);
            this.TextBoxAddContactName.Name = "TextBoxAddContactName";
            this.TextBoxAddContactName.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddContactName.TabIndex = 5;
            // 
            // TextBoxAddContactAdress
            // 
            this.TextBoxAddContactAdress.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddContactAdress.Location = new System.Drawing.Point(118, 35);
            this.TextBoxAddContactAdress.Name = "TextBoxAddContactAdress";
            this.TextBoxAddContactAdress.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddContactAdress.TabIndex = 6;
            // 
            // TextBoxAddContactPhone
            // 
            this.TextBoxAddContactPhone.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddContactPhone.Location = new System.Drawing.Point(118, 61);
            this.TextBoxAddContactPhone.Name = "TextBoxAddContactPhone";
            this.TextBoxAddContactPhone.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddContactPhone.TabIndex = 7;
            // 
            // FormAddContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 134);
            this.Controls.Add(this.TextBoxAddContactPhone);
            this.Controls.Add(this.TextBoxAddContactAdress);
            this.Controls.Add(this.TextBoxAddContactName);
            this.Controls.Add(this.LabelAddContactPhone);
            this.Controls.Add(this.LabelAddContactAdress);
            this.Controls.Add(this.LabelAddContactName);
            this.Controls.Add(this.ButtonAddContactCancel);
            this.Controls.Add(this.ButtonAddContactConfirm);
            this.Name = "FormAddContact";
            this.Text = "Ajouter un contact";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAddContactConfirm;
        private System.Windows.Forms.Button ButtonAddContactCancel;
        private System.Windows.Forms.Label LabelAddContactName;
        private System.Windows.Forms.Label LabelAddContactAdress;
        private System.Windows.Forms.Label LabelAddContactPhone;
        private System.Windows.Forms.TextBox TextBoxAddContactName;
        private System.Windows.Forms.TextBox TextBoxAddContactAdress;
        private System.Windows.Forms.TextBox TextBoxAddContactPhone;
    }
}