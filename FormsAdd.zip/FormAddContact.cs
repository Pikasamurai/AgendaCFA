﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MysqlContact
{
    public partial class FormAddContact : Form
    {
        public FormAddContact()
        {
            InitializeComponent();
        }

        private void ButtonAddContactConfirm_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
        
        private void ButtonAddContactCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
