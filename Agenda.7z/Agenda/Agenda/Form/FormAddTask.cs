﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class FormAddTask : Form
    {
        public FormAddTask()
        {
            InitializeComponent();
        }

        private Form2 form2;

        public Form2 Form2 { get => form2; set => form2 = value; }

        //Méthodes d'annulation & de confirmation d'ajout de tâchess
        private void ButtonAddTaskCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonAddTaskConfirm_Click(object sender, EventArgs e)
        {
            TaskDAO taskdao = new TaskDAO();
            TaskModel task = (TaskModel)taskdao.create(new TaskModel(DAO.Id_sess, TextBoxAddTaskName.Text, TextBoxAddTaskComment.Text ,TextBoxAddTaskDate.Text));
            form2.refresh();
        }
    }
}
