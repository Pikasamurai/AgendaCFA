﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class FormAddTask : Form
    {
        public FormAddTask()
        {
            InitializeComponent();
        }

        private FormAgenda FormAgenda;

        public FormAgenda Formagenda { get => FormAgenda; set => FormAgenda = value; }

        //Méthodes d'annulation & de confirmation d'ajout de tâchess
        private void ButtonAddTaskCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ButtonAddTaskConfirm_Click(object sender, EventArgs e)
        {
            TaskDAO taskdao = new TaskDAO();
            TaskModel task = (TaskModel)taskdao.create(new TaskModel(DAO.Id_sess, TextBoxAddTaskName.Text, TextBoxAddTaskComment.Text ,TextBoxAddTaskDate.Text));
            FormAgenda.refresh();
        }
    }
}
