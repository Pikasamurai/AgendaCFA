﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class FormAgenda : Form
    {
        public FormAgenda()
        {
            InitializeComponent();
        }

        //Bouton d'affichage du groupe d'éléments des tâches
        private void ButtonTask_Click(object sender, EventArgs e)
        {
            groupBox_Task.Visible = true;
            groupBox_Contact.Visible = false;
            groupBox_Note.Visible = false;
        }

        //Bouton d'affichage du groupe d'éléments des contacts
        private void ButtonContact_Click(object sender, EventArgs e)
        {
            groupBox_Contact.Visible = true;
            groupBox_Task.Visible = false;
            groupBox_Note.Visible = false;
        }

        //Bouton d'affichage du groupe d'éléments des notes
        private void ButtonNote_Click(object sender, EventArgs e)
        {
            groupBox_Note.Visible = true;
            groupBox_Contact.Visible = false;
            groupBox_Task.Visible = false;
        }

        //Load de la méthode refresh
        private void FormAgenda_Load(object sender, EventArgs e)
        {
            refresh();
        }

        //Méthode d'actualisation des listes
        public void refresh()
        {
            listBox_Task.Items.Clear();
            listBox_Contact.Items.Clear();
            listBox_Note.Items.Clear();

            TaskDAO taskdao = new TaskDAO();
            ContactDAO contactdao = new ContactDAO();
            NoteDAO notedao = new NoteDAO();
            UserDAO userdao = new UserDAO();

            List<TaskModel> tasks = (List<TaskModel>)taskdao.find(new TaskModel(DAO.Id_sess));
            List<ContactModel> contacts = (List<ContactModel>)contactdao.find(new ContactModel(DAO.Id_sess));
            List<NoteModel> notes = (List<NoteModel>)notedao.find(new NoteModel(DAO.Id_sess));

            listBox_Task.DisplayMember = "Name_task";
            listBox_Task.ValueMember = "Id_task";
            foreach (TaskModel task in tasks)
            {
                listBox_Task.Items.Add(task);
            }

            listBox_Contact.DisplayMember = "Name_contact";
            listBox_Contact.ValueMember = "Id_contact";
            foreach (ContactModel contact in contacts)
            {
                listBox_Contact.Items.Add(contact);
            }

            listBox_Note.DisplayMember = "Title_note";
            listBox_Note.ValueMember = "Id_note";
            foreach (NoteModel note in notes)
            {
                listBox_Note.Items.Add(note);
            }
        }

        //Bouton d'affichage de la forme d'ajout de contacts
        private void ButtonAddContact_Click(object sender, EventArgs e)
        {
            FormAddContact addContact = new FormAddContact();
            addContact.Formagenda = this;
            addContact.ShowDialog();
        }

        //Bouton d'affichage de la forme d'ajout de tâches
        private void ButtonAddTask_Click(object sender, EventArgs e)
        {
            FormAddTask addTask = new FormAddTask();
            addTask.Formagenda = this;
            addTask.ShowDialog();
        }

        //Bouton d'affichage de la forme d'ajout de notes
        private void ButtonAddNote_Click(object sender, EventArgs e)
        {
            FormAddNote addNote = new FormAddNote();
            addNote.Formagenda = this;
            addNote.ShowDialog();
        }

        //Méthode de récupération d'id d'un élément de liste de tâche sélectionné
        private void listBox_Task_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Task.SelectedItem != null)
            {
                Info1.Text = "";
                Info2.Text = "";
                Info3.Text = "";

                TaskModel selected = (TaskModel)listBox_Task.SelectedItem;
                string name_task = selected.Name_task;
                string date_task = selected.Date_task;
                string comment_task = selected.Comment_task;

                Info1.Text = "Nom: "+name_task;
                Info2.Text = "Date: "+date_task;
                Info3.Text = "Commentaire: "+comment_task;

                textBoxUpdate1.Text = name_task;
                textBoxUpdate2.Text = date_task;
                textBoxUpdate3.Text = comment_task;


                label_type.Text = "Tâche";
            }
            
        }

        //Méthode de récupération d'id d'un élément de liste de contact sélectionné
        private void listBox_Contact_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Contact.SelectedItem != null)
            {
                Info1.Text = "";
                Info2.Text = "";
                Info3.Text = "";

                ContactModel selected = (ContactModel)listBox_Contact.SelectedItem;
                string name_contact = selected.Name_contact;
                string phone_contact = selected.Phone_contact;
                string adress_contact = selected.Adress_contact;                

                Info1.Text = "Nom: "+name_contact;
                Info2.Text = "Telephone: " + phone_contact;
                Info3.Text = "Adresse: " + adress_contact;

                textBoxUpdate1.Text = name_contact;
                textBoxUpdate2.Text = phone_contact;
                textBoxUpdate3.Text = adress_contact;

                label_type.Text = "Contact";
            }
        }

        //Méthode de récupération d'id d'un élément de liste de note sélectionné
        private void listBox_Note_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_Note.SelectedItem != null)
            {
                Info1.Text = "";
                Info2.Text = "";
                Info3.Text = "";

                NoteModel selected = (NoteModel)listBox_Note.SelectedItem;
                string title_note = selected.Title_note;
                string comment_note = selected.Comment_note;

                Info1.Text = "Titre: "+title_note;
                Info2.Text = "Commentaire: "+comment_note;

                textBoxUpdate1.Text = title_note;
                textBoxUpdate3.Text = comment_note;

                label_type.Text = "Note";
            }
        }

        //Button de modification des éléments de listes
        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if(label_type.Text == "Tâche")
            {
                TaskDAO taskdao = new TaskDAO();
                TaskModel selected = (TaskModel)listBox_Task.SelectedItem;
                int id_task = selected.Id_task;
                TaskModel task = (TaskModel)taskdao.update(new TaskModel(id_task, DAO.Id_sess, textBoxUpdate1.Text, textBoxUpdate3.Text, textBoxUpdate2.Text));
                refresh();
            }
            if(label_type.Text == "Contact")
            {
                ContactDAO contactdao = new ContactDAO();
                ContactModel selected = (ContactModel)listBox_Contact.SelectedItem;
                int id_contact = selected.Id_contact;
                ContactModel contact = (ContactModel)contactdao.update(new ContactModel(id_contact, DAO.Id_sess, textBoxUpdate1.Text, textBoxUpdate3.Text, textBoxUpdate2.Text));
                refresh();
            }
            if(label_type.Text == "Note")
            {
                NoteDAO notedao = new NoteDAO();
                NoteModel selected = (NoteModel)listBox_Note.SelectedItem;
                int id_note = selected.Id_note;
                NoteModel note = (NoteModel)notedao.update(new NoteModel(id_note, DAO.Id_sess, textBoxUpdate1.Text, textBoxUpdate3.Text));
                refresh();
            }
        }

        //Bouton de suppression de tâches
        private void button_DeleteTask_Click(object sender, EventArgs e)
        {
            TaskDAO taskdao = new TaskDAO();
            TaskModel selected = (TaskModel)listBox_Task.SelectedItem;
            int id_task = selected.Id_task;
            TaskModel task = (TaskModel)taskdao.delete(new TaskModel(id_task, DAO.Id_sess));
            refresh();
        }

        //Bouton de suppression de contacts
        private void button_DeleteContact_Click(object sender, EventArgs e)
        {
            ContactDAO contactdao = new ContactDAO();
            ContactModel selected = (ContactModel)listBox_Contact.SelectedItem;
            int id_contact = selected.Id_contact;
            ContactModel contact = (ContactModel)contactdao.delete(new ContactModel(id_contact, DAO.Id_sess));
            refresh();
        }

        //Bouton de suppression de notes
        private void  button_DeleteNote_Click(object sender, EventArgs e)
        {
            NoteDAO notedao = new NoteDAO();
            NoteModel selected = (NoteModel)listBox_Note.SelectedItem;
            int id_note = selected.Id_note;
            NoteModel note = (NoteModel)notedao.delete(new NoteModel(id_note, DAO.Id_sess));
            refresh();
        }
    }
}
