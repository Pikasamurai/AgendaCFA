﻿using System;

namespace Agenda
{
    partial class FormAddNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ButtonAddNoteConfirm = new System.Windows.Forms.Button();
            this.ButtonAddNoteCancel = new System.Windows.Forms.Button();
            this.LabelAddNoteTitle = new System.Windows.Forms.Label();
            this.TextBoxAddNoteTitle = new System.Windows.Forms.TextBox();
            this.TextBoxAddNoteComment = new System.Windows.Forms.TextBox();
            this.LabelAddNoteComment = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ButtonAddNoteConfirm
            // 
            this.ButtonAddNoteConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddNoteConfirm.Location = new System.Drawing.Point(96, 191);
            this.ButtonAddNoteConfirm.Name = "ButtonAddNoteConfirm";
            this.ButtonAddNoteConfirm.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddNoteConfirm.TabIndex = 0;
            this.ButtonAddNoteConfirm.Text = "Confirmer";
            this.ButtonAddNoteConfirm.UseVisualStyleBackColor = true;
            this.ButtonAddNoteConfirm.Click += new System.EventHandler(this.ButtonAddNoteConfirm_Click);
            // 
            // ButtonAddNoteCancel
            // 
            this.ButtonAddNoteCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ButtonAddNoteCancel.Location = new System.Drawing.Point(177, 191);
            this.ButtonAddNoteCancel.Name = "ButtonAddNoteCancel";
            this.ButtonAddNoteCancel.Size = new System.Drawing.Size(75, 23);
            this.ButtonAddNoteCancel.TabIndex = 1;
            this.ButtonAddNoteCancel.Text = "Annuler";
            this.ButtonAddNoteCancel.UseVisualStyleBackColor = true;
            this.ButtonAddNoteCancel.Click += new System.EventHandler(this.ButtonAddNoteCancel_Click);
            // 
            // LabelAddNoteTitle
            // 
            this.LabelAddNoteTitle.Location = new System.Drawing.Point(12, 9);
            this.LabelAddNoteTitle.Name = "LabelAddNoteTitle";
            this.LabelAddNoteTitle.Size = new System.Drawing.Size(100, 20);
            this.LabelAddNoteTitle.TabIndex = 2;
            this.LabelAddNoteTitle.Text = "Titre";
            this.LabelAddNoteTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxAddNoteTitle
            // 
            this.TextBoxAddNoteTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddNoteTitle.Location = new System.Drawing.Point(118, 9);
            this.TextBoxAddNoteTitle.Name = "TextBoxAddNoteTitle";
            this.TextBoxAddNoteTitle.Size = new System.Drawing.Size(127, 20);
            this.TextBoxAddNoteTitle.TabIndex = 5;
            // 
            // TextBoxAddNoteComment
            // 
            this.TextBoxAddNoteComment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBoxAddNoteComment.Location = new System.Drawing.Point(12, 58);
            this.TextBoxAddNoteComment.Multiline = true;
            this.TextBoxAddNoteComment.Name = "TextBoxAddNoteComment";
            this.TextBoxAddNoteComment.Size = new System.Drawing.Size(233, 98);
            this.TextBoxAddNoteComment.TabIndex = 6;
            // 
            // LabelAddNoteComment
            // 
            this.LabelAddNoteComment.Location = new System.Drawing.Point(12, 35);
            this.LabelAddNoteComment.Name = "LabelAddNoteComment";
            this.LabelAddNoteComment.Size = new System.Drawing.Size(100, 20);
            this.LabelAddNoteComment.TabIndex = 3;
            this.LabelAddNoteComment.Text = "Commentaire";
            this.LabelAddNoteComment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FormAddNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 226);
            this.Controls.Add(this.TextBoxAddNoteComment);
            this.Controls.Add(this.TextBoxAddNoteTitle);
            this.Controls.Add(this.LabelAddNoteComment);
            this.Controls.Add(this.LabelAddNoteTitle);
            this.Controls.Add(this.ButtonAddNoteCancel);
            this.Controls.Add(this.ButtonAddNoteConfirm);
            this.Name = "FormAddNote";
            this.Text = "Ajouter une note";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ButtonAddNoteConfirm;
        private System.Windows.Forms.Button ButtonAddNoteCancel;
        private System.Windows.Forms.Label LabelAddNoteTitle;
        private System.Windows.Forms.Label LabelAddNoteComment;
        private System.Windows.Forms.TextBox TextBoxAddNoteTitle;
        private System.Windows.Forms.TextBox TextBoxAddNoteComment;
    }
}