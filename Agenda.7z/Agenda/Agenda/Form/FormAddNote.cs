﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class FormAddNote : Form
    {
        public FormAddNote()
        {
            InitializeComponent();
        }

        private Form2 form2;

        public Form2 Form2 { get => form2; set => form2 = value; }

        //Méthodes d'annulation & de confirmation d'ajout de note
        private void ButtonAddNoteCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void ButtonAddNoteConfirm_Click(object sender, EventArgs e)
        {
            NoteDAO notedao = new NoteDAO();
            NoteModel Note = (NoteModel)notedao.create(new NoteModel(DAO.Id_sess, TextBoxAddNoteTitle.Text, TextBoxAddNoteComment.Text));
            form2.refresh();
        }
    }
}
