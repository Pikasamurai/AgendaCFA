﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //Bouton de connexion
        private void sign_up_Click(object sender, EventArgs e)
        {
            if((username_sign_up.Text == "") || (password_sign_up.Text == ""))
            {
                MessageBox.Show("Remplir tous les champs");
            }
            else
            {
                UserDAO userdao = new UserDAO();
                UserModel user = (UserModel)userdao.create(new UserModel(username_sign_up.Text, password_sign_up.Text));
            }
        }

        //Bouton d'inscription
        private void sign_in_Click(object sender, EventArgs e)
        {

            if ((username_sign_in.Text == "") || (password_sign_in.Text == ""))
            {
                MessageBox.Show("Remplir tous les champs");
            }
            else
            {
                UserDAO userdao = new UserDAO();
                int id_user = (int)userdao.find(new UserModel(username_sign_in.Text, password_sign_in.Text));
                if(id_user != 0)
                {
                    this.Hide();
                    Form2 form2 = new Form2();
                    form2.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Identifiant incorrect");
                }
            }  
        }

        private void username_sign_up_TextChanged(object sender, EventArgs e)
        {

        }

        private void pasword_sign_up_TextChanged(object sender, EventArgs e)
        {

        }

        private void password_connection_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
        }

        private void label6_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }

    }
}
