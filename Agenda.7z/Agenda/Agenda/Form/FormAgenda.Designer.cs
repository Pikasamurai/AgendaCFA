﻿namespace Agenda
{
    partial class FormAgenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleAgenda = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ButtonNote = new System.Windows.Forms.Button();
            this.ButtonContact = new System.Windows.Forms.Button();
            this.ButtonTask = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox_Task = new System.Windows.Forms.GroupBox();
            this.listBox_Task = new System.Windows.Forms.ListBox();
            this.button_AddTask = new System.Windows.Forms.Button();
            this.button_DeleteTask = new System.Windows.Forms.Button();
            this.groupBox_Contact = new System.Windows.Forms.GroupBox();
            this.listBox_Contact = new System.Windows.Forms.ListBox();
            this.button_AddContact = new System.Windows.Forms.Button();
            this.button_DeleteContact = new System.Windows.Forms.Button();
            this.groupBox_Note = new System.Windows.Forms.GroupBox();
            this.listBox_Note = new System.Windows.Forms.ListBox();
            this.button_AddNote = new System.Windows.Forms.Button();
            this.button_DeleteNote = new System.Windows.Forms.Button();
            this.calendar1 = new Calendar.NET.Calendar();
            this.groupBox_Information = new System.Windows.Forms.GroupBox();
            this.Info3 = new System.Windows.Forms.Label();
            this.Info2 = new System.Windows.Forms.Label();
            this.Info1 = new System.Windows.Forms.Label();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.textBoxUpdate3 = new System.Windows.Forms.TextBox();
            this.textBoxUpdate1 = new System.Windows.Forms.TextBox();
            this.groupBoxModifier = new System.Windows.Forms.GroupBox();
            this.label_type = new System.Windows.Forms.Label();
            this.textBoxUpdate2 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox_Task.SuspendLayout();
            this.groupBox_Contact.SuspendLayout();
            this.groupBox_Note.SuspendLayout();
            this.groupBox_Information.SuspendLayout();
            this.groupBoxModifier.SuspendLayout();
            this.SuspendLayout();
            // 
            // TitleAgenda
            // 
            this.TitleAgenda.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TitleAgenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleAgenda.Location = new System.Drawing.Point(292, 9);
            this.TitleAgenda.Name = "TitleAgenda";
            this.TitleAgenda.Size = new System.Drawing.Size(431, 31);
            this.TitleAgenda.TabIndex = 1;
            this.TitleAgenda.Text = "Agenda";
            this.TitleAgenda.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.ButtonNote);
            this.panel1.Controls.Add(this.ButtonContact);
            this.panel1.Controls.Add(this.ButtonTask);
            this.panel1.Location = new System.Drawing.Point(674, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(99, 103);
            this.panel1.TabIndex = 0;
            // 
            // ButtonNote
            // 
            this.ButtonNote.Location = new System.Drawing.Point(13, 61);
            this.ButtonNote.Name = "ButtonNote";
            this.ButtonNote.Size = new System.Drawing.Size(75, 23);
            this.ButtonNote.TabIndex = 2;
            this.ButtonNote.Text = "Note";
            this.ButtonNote.UseVisualStyleBackColor = true;
            this.ButtonNote.Click += new System.EventHandler(this.ButtonNote_Click);
            // 
            // ButtonContact
            // 
            this.ButtonContact.Location = new System.Drawing.Point(13, 32);
            this.ButtonContact.Name = "ButtonContact";
            this.ButtonContact.Size = new System.Drawing.Size(75, 23);
            this.ButtonContact.TabIndex = 1;
            this.ButtonContact.Text = "Contact";
            this.ButtonContact.UseVisualStyleBackColor = true;
            this.ButtonContact.Click += new System.EventHandler(this.ButtonContact_Click);
            // 
            // ButtonTask
            // 
            this.ButtonTask.Location = new System.Drawing.Point(13, 3);
            this.ButtonTask.Name = "ButtonTask";
            this.ButtonTask.Size = new System.Drawing.Size(75, 23);
            this.ButtonTask.TabIndex = 0;
            this.ButtonTask.Text = "Tâches";
            this.ButtonTask.UseVisualStyleBackColor = true;
            this.ButtonTask.Click += new System.EventHandler(this.ButtonTask_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.26289F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.73711F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.calendar1, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 43);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.3038F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.69621F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(776, 449);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox_Task);
            this.panel2.Controls.Add(this.groupBox_Contact);
            this.panel2.Controls.Add(this.groupBox_Note);
            this.panel2.Location = new System.Drawing.Point(556, 112);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(217, 334);
            this.panel2.TabIndex = 9;
            // 
            // groupBox_Task
            // 
            this.groupBox_Task.Controls.Add(this.listBox_Task);
            this.groupBox_Task.Controls.Add(this.button_AddTask);
            this.groupBox_Task.Controls.Add(this.button_DeleteTask);
            this.groupBox_Task.Location = new System.Drawing.Point(0, 0);
            this.groupBox_Task.Name = "groupBox_Task";
            this.groupBox_Task.Size = new System.Drawing.Size(214, 334);
            this.groupBox_Task.TabIndex = 3;
            this.groupBox_Task.TabStop = false;
            this.groupBox_Task.Text = "Tâches";
            // 
            // listBox_Task
            // 
            this.listBox_Task.FormattingEnabled = true;
            this.listBox_Task.Location = new System.Drawing.Point(7, 20);
            this.listBox_Task.Name = "listBox_Task";
            this.listBox_Task.Size = new System.Drawing.Size(201, 277);
            this.listBox_Task.TabIndex = 1;
            this.listBox_Task.SelectedIndexChanged += new System.EventHandler(this.listBox_Task_SelectedIndexChanged);
            // 
            // button_AddTask
            // 
            this.button_AddTask.Location = new System.Drawing.Point(6, 303);
            this.button_AddTask.Name = "button_AddTask";
            this.button_AddTask.Size = new System.Drawing.Size(82, 23);
            this.button_AddTask.TabIndex = 2;
            this.button_AddTask.Text = "Ajouter";
            this.button_AddTask.UseVisualStyleBackColor = true;
            this.button_AddTask.Click += new System.EventHandler(this.ButtonAddTask_Click);
            // 
            // button_DeleteTask
            // 
            this.button_DeleteTask.Location = new System.Drawing.Point(126, 303);
            this.button_DeleteTask.Name = "button_DeleteTask";
            this.button_DeleteTask.Size = new System.Drawing.Size(82, 23);
            this.button_DeleteTask.TabIndex = 3;
            this.button_DeleteTask.Text = "Supprimer";
            this.button_DeleteTask.UseVisualStyleBackColor = true;
            this.button_DeleteTask.Click += new System.EventHandler(this.button_DeleteTask_Click);
            // 
            // groupBox_Contact
            // 
            this.groupBox_Contact.Controls.Add(this.listBox_Contact);
            this.groupBox_Contact.Controls.Add(this.button_AddContact);
            this.groupBox_Contact.Controls.Add(this.button_DeleteContact);
            this.groupBox_Contact.Location = new System.Drawing.Point(0, 0);
            this.groupBox_Contact.Name = "groupBox_Contact";
            this.groupBox_Contact.Size = new System.Drawing.Size(214, 334);
            this.groupBox_Contact.TabIndex = 11;
            this.groupBox_Contact.TabStop = false;
            this.groupBox_Contact.Text = "Contact";
            // 
            // listBox_Contact
            // 
            this.listBox_Contact.FormattingEnabled = true;
            this.listBox_Contact.Location = new System.Drawing.Point(7, 20);
            this.listBox_Contact.Name = "listBox_Contact";
            this.listBox_Contact.Size = new System.Drawing.Size(201, 277);
            this.listBox_Contact.TabIndex = 0;
            this.listBox_Contact.SelectedIndexChanged += new System.EventHandler(this.listBox_Contact_SelectedIndexChanged);
            // 
            // button_AddContact
            // 
            this.button_AddContact.Location = new System.Drawing.Point(6, 303);
            this.button_AddContact.Name = "button_AddContact";
            this.button_AddContact.Size = new System.Drawing.Size(82, 23);
            this.button_AddContact.TabIndex = 1;
            this.button_AddContact.Text = "Ajouter";
            this.button_AddContact.UseVisualStyleBackColor = true;
            this.button_AddContact.Click += new System.EventHandler(this.ButtonAddContact_Click);
            // 
            // button_DeleteContact
            // 
            this.button_DeleteContact.Location = new System.Drawing.Point(126, 303);
            this.button_DeleteContact.Name = "button_DeleteContact";
            this.button_DeleteContact.Size = new System.Drawing.Size(82, 23);
            this.button_DeleteContact.TabIndex = 2;
            this.button_DeleteContact.Text = "Supprimer";
            this.button_DeleteContact.UseVisualStyleBackColor = true;
            this.button_DeleteContact.Click += new System.EventHandler(this.button_DeleteContact_Click);
            // 
            // groupBox_Note
            // 
            this.groupBox_Note.Controls.Add(this.listBox_Note);
            this.groupBox_Note.Controls.Add(this.button_AddNote);
            this.groupBox_Note.Controls.Add(this.button_DeleteNote);
            this.groupBox_Note.Location = new System.Drawing.Point(0, 0);
            this.groupBox_Note.Name = "groupBox_Note";
            this.groupBox_Note.Size = new System.Drawing.Size(214, 334);
            this.groupBox_Note.TabIndex = 10;
            this.groupBox_Note.TabStop = false;
            this.groupBox_Note.Text = "Note";
            // 
            // listBox_Note
            // 
            this.listBox_Note.FormattingEnabled = true;
            this.listBox_Note.Location = new System.Drawing.Point(7, 20);
            this.listBox_Note.Name = "listBox_Note";
            this.listBox_Note.Size = new System.Drawing.Size(201, 277);
            this.listBox_Note.TabIndex = 0;
            this.listBox_Note.SelectedIndexChanged += new System.EventHandler(this.listBox_Note_SelectedIndexChanged);
            // 
            // button_AddNote
            // 
            this.button_AddNote.Location = new System.Drawing.Point(6, 303);
            this.button_AddNote.Name = "button_AddNote";
            this.button_AddNote.Size = new System.Drawing.Size(82, 23);
            this.button_AddNote.TabIndex = 1;
            this.button_AddNote.Text = "Ajouter";
            this.button_AddNote.UseVisualStyleBackColor = true;
            this.button_AddNote.Click += new System.EventHandler(this.ButtonAddNote_Click);
            // 
            // button_DeleteNote
            // 
            this.button_DeleteNote.Location = new System.Drawing.Point(126, 303);
            this.button_DeleteNote.Name = "button_DeleteNote";
            this.button_DeleteNote.Size = new System.Drawing.Size(82, 23);
            this.button_DeleteNote.TabIndex = 2;
            this.button_DeleteNote.Text = "Supprimer";
            this.button_DeleteNote.UseVisualStyleBackColor = true;
            this.button_DeleteNote.Click += new System.EventHandler(this.button_DeleteNote_Click);
            // 
            // calendar1
            // 
            this.calendar1.AllowEditingEvents = true;
            this.calendar1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.calendar1.CalendarDate = new System.DateTime(2019, 12, 9, 15, 45, 48, 474);
            this.calendar1.CalendarView = Calendar.NET.CalendarViews.Month;
            this.calendar1.DateHeaderFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.calendar1.DayOfWeekFont = new System.Drawing.Font("Arial", 10F);
            this.calendar1.DaysFont = new System.Drawing.Font("Arial", 10F);
            this.calendar1.DayViewTimeFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.calendar1.DimDisabledEvents = true;
            this.calendar1.HighlightCurrentDay = true;
            this.calendar1.LoadPresetHolidays = true;
            this.calendar1.Location = new System.Drawing.Point(3, 112);
            this.calendar1.Name = "calendar1";
            this.calendar1.ShowArrowControls = true;
            this.calendar1.ShowDashedBorderOnDisabledEvents = true;
            this.calendar1.ShowDateInHeader = true;
            this.calendar1.ShowDisabledEvents = false;
            this.calendar1.ShowEventTooltips = true;
            this.calendar1.ShowTodayButton = true;
            this.calendar1.Size = new System.Drawing.Size(547, 334);
            this.calendar1.TabIndex = 8;
            this.calendar1.TodayFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            // 
            // groupBox_Information
            // 
            this.groupBox_Information.Controls.Add(this.Info3);
            this.groupBox_Information.Controls.Add(this.Info2);
            this.groupBox_Information.Controls.Add(this.Info1);
            this.groupBox_Information.Location = new System.Drawing.Point(794, 155);
            this.groupBox_Information.Name = "groupBox_Information";
            this.groupBox_Information.Size = new System.Drawing.Size(200, 170);
            this.groupBox_Information.TabIndex = 4;
            this.groupBox_Information.TabStop = false;
            this.groupBox_Information.Text = "Information";
            // 
            // Info3
            // 
            this.Info3.AutoSize = true;
            this.Info3.Location = new System.Drawing.Point(6, 110);
            this.Info3.MaximumSize = new System.Drawing.Size(180, 40);
            this.Info3.MinimumSize = new System.Drawing.Size(180, 40);
            this.Info3.Name = "Info3";
            this.Info3.Size = new System.Drawing.Size(180, 40);
            this.Info3.TabIndex = 12;
            // 
            // Info2
            // 
            this.Info2.AutoSize = true;
            this.Info2.Location = new System.Drawing.Point(6, 70);
            this.Info2.Name = "Info2";
            this.Info2.Size = new System.Drawing.Size(0, 13);
            this.Info2.TabIndex = 11;
            // 
            // Info1
            // 
            this.Info1.AutoSize = true;
            this.Info1.Location = new System.Drawing.Point(6, 30);
            this.Info1.Name = "Info1";
            this.Info1.Size = new System.Drawing.Size(0, 13);
            this.Info1.TabIndex = 10;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Location = new System.Drawing.Point(63, 173);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdate.TabIndex = 15;
            this.buttonUpdate.Text = "Modifier";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // textBoxUpdate3
            // 
            this.textBoxUpdate3.Location = new System.Drawing.Point(9, 93);
            this.textBoxUpdate3.Multiline = true;
            this.textBoxUpdate3.Name = "textBoxUpdate3";
            this.textBoxUpdate3.Size = new System.Drawing.Size(185, 74);
            this.textBoxUpdate3.TabIndex = 14;
            // 
            // textBoxUpdate1
            // 
            this.textBoxUpdate1.Location = new System.Drawing.Point(9, 32);
            this.textBoxUpdate1.Name = "textBoxUpdate1";
            this.textBoxUpdate1.Size = new System.Drawing.Size(185, 20);
            this.textBoxUpdate1.TabIndex = 13;
            // 
            // groupBoxModifier
            // 
            this.groupBoxModifier.Controls.Add(this.label_type);
            this.groupBoxModifier.Controls.Add(this.textBoxUpdate2);
            this.groupBoxModifier.Controls.Add(this.textBoxUpdate1);
            this.groupBoxModifier.Controls.Add(this.buttonUpdate);
            this.groupBoxModifier.Controls.Add(this.textBoxUpdate3);
            this.groupBoxModifier.Location = new System.Drawing.Point(791, 325);
            this.groupBoxModifier.Name = "groupBoxModifier";
            this.groupBoxModifier.Size = new System.Drawing.Size(200, 211);
            this.groupBoxModifier.TabIndex = 16;
            this.groupBoxModifier.TabStop = false;
            this.groupBoxModifier.Text = "Modifier";
            // 
            // label_type
            // 
            this.label_type.AutoSize = true;
            this.label_type.Location = new System.Drawing.Point(78, 16);
            this.label_type.Name = "label_type";
            this.label_type.Size = new System.Drawing.Size(0, 13);
            this.label_type.TabIndex = 17;
            // 
            // textBoxUpdate2
            // 
            this.textBoxUpdate2.Location = new System.Drawing.Point(9, 58);
            this.textBoxUpdate2.Name = "textBoxUpdate2";
            this.textBoxUpdate2.Size = new System.Drawing.Size(185, 20);
            this.textBoxUpdate2.TabIndex = 16;
            // 
            // FormAgenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1007, 569);
            this.Controls.Add(this.groupBoxModifier);
            this.Controls.Add(this.groupBox_Information);
            this.Controls.Add(this.TitleAgenda);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FormAgenda";
            this.Text = "Agenda";
            this.Load += new System.EventHandler(this.FormAgenda_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox_Task.ResumeLayout(false);
            this.groupBox_Contact.ResumeLayout(false);
            this.groupBox_Note.ResumeLayout(false);
            this.groupBox_Information.ResumeLayout(false);
            this.groupBox_Information.PerformLayout();
            this.groupBoxModifier.ResumeLayout(false);
            this.groupBoxModifier.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label TitleAgenda;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ButtonContact;
        private System.Windows.Forms.Button ButtonTask;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button ButtonNote;
        private Calendar.NET.Calendar calendar1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_DeleteNote;
        private System.Windows.Forms.Button button_AddNote;
        private System.Windows.Forms.ListBox listBox_Note;
        private System.Windows.Forms.GroupBox groupBox_Task;
        private System.Windows.Forms.Button button_DeleteTask;
        private System.Windows.Forms.Button button_AddTask;
        private System.Windows.Forms.ListBox listBox_Task;
        private System.Windows.Forms.GroupBox groupBox_Note;
        private System.Windows.Forms.GroupBox groupBox_Contact;
        private System.Windows.Forms.ListBox listBox_Contact;
        private System.Windows.Forms.Button button_AddContact;
        private System.Windows.Forms.Button button_DeleteContact;
        private System.Windows.Forms.GroupBox groupBox_Information;
        private System.Windows.Forms.Label Info3;
        private System.Windows.Forms.Label Info2;
        private System.Windows.Forms.Label Info1;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TextBox textBoxUpdate3;
        private System.Windows.Forms.TextBox textBoxUpdate1;
        private System.Windows.Forms.GroupBox groupBoxModifier;
        private System.Windows.Forms.TextBox textBoxUpdate2;
        private System.Windows.Forms.Label label_type;
    }
}