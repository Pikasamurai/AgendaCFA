﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    public abstract class DAO
    {
        //attributs du DAO
        private ConnectionBdd connect = null;
        private static int id_sess;

        //Getter/Setter de la connexion
        internal ConnectionBdd Connect { get => connect; set => connect = value; }
        public static int Id_sess { get => id_sess; set => id_sess = value; }

        //Connecte a l'instance de la connexion a la BDD
        public DAO()
        {
            this.connect = ConnectionBdd.getInstance();
        }

        //Méthode sql 
        public abstract Object create(Object obj);

        public abstract Object delete(Object obj);

        public abstract Object update(Object obj);

        public abstract Object find(Object obj); 

       
    }
}
