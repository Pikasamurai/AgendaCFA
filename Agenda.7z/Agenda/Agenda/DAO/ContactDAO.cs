﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public class ContactDAO : DAO

    {
        public ContactDAO() : base()
        {

        }

        //Méthode DAO de création de Contact
        public override Object create(Object obj)
        {
            ContactModel contact = (ContactModel)obj;
            try
            {
                string request = "INSERT INTO contact (id_contact,id_contactuser_fk,name_contact,adress_contact,phone_contact) VALUES " +
                    "(@id_contact, @id_contactuser_fk, @name_contact, @adress_contact, @phone_contact)";

                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                command.Parameters.Add("@id_contact", MySqlDbType.Int32);
                command.Parameters.Add("@id_contactuser_fk", MySqlDbType.Int32);
                command.Parameters.Add("@name_contact", MySqlDbType.VarChar);
                command.Parameters.Add("@adress_contact", MySqlDbType.VarChar);
                command.Parameters.Add("@phone_contact", MySqlDbType.VarChar);

                command.Parameters["@id_contact"].Value = null;
                command.Parameters["@id_contactuser_fk"].Value = contact.Id_contactuser_fk;
                command.Parameters["@name_contact"].Value = contact.Name_contact;
                command.Parameters["@adress_contact"].Value = contact.Adress_contact;
                command.Parameters["@phone_contact"].Value = contact.Phone_contact;

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Contact bien ajouté");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return contact;
        }

        //Méthode DAO de suppression de Contact
        public override Object delete(Object obj)
        {
            ContactModel contact = (ContactModel)obj;

            try
            {
                string request = "DELETE FROM contact WHERE id_contact =" + contact.Id_contact;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre contact à bien été supprimé");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return contact;
        }

        //Méthode DAO de modification de Contact
        public override Object update(Object obj)
        {
            ContactModel contact = (ContactModel)obj;
            try
            {
                string request = "UPDATE contact SET name_contact = @New_name_contact, adress_contact = @New_adress_contact, phone_contact = @New_phone_contact" +
                    " WHERE id_contact = " + contact.Id_contact;



                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);



                command.Parameters.Add("@New_name_contact", MySqlDbType.VarChar);
                command.Parameters.Add("@New_adress_contact", MySqlDbType.VarChar);
                command.Parameters.Add("@New_phone_contact", MySqlDbType.VarChar);


                command.Parameters["@New_name_contact"].Value = contact.Name_contact;
                command.Parameters["@New_adress_contact"].Value = contact.Adress_contact;
                command.Parameters["@New_phone_contact"].Value = contact.Phone_contact;

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre contact a bien été modifiée");
                dataReader.Close();

            }
            catch (MySqlException exc)

            {
                MessageBox.Show(exc.ToString());
            }

            return contact;
        }

        //Méthode DAO de recherche de Contact
        public override Object find(Object obj)
        {
            ContactModel contact = (ContactModel)obj;
            UserModel user = new UserModel();
            try
            {
                string request = "SELECT * from contact WHERE id_contactuser_fk = " + contact.Id_contactuser_fk;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);
                MySqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int id_contact_reader = Convert.ToInt32(dataReader.GetValue(0));
                    string name_contact_reader = dataReader.GetValue(2).ToString();
                    string adress_contact_reader = dataReader.GetValue(3).ToString();
                    string phone_contact_reader = dataReader.GetValue(4).ToString();
                    user.List_contact.Add(new ContactModel() { Id_contact = id_contact_reader, Name_contact = name_contact_reader, Adress_contact = adress_contact_reader, Phone_contact = phone_contact_reader });
                }

                dataReader.Close();
            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }
            return user.List_contact;
        }




    }
}
