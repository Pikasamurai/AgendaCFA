﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    public class NoteDAO : DAO

    {

        public NoteDAO() : base()
        {

        }

        //Méthode DAO de création de note
        public override Object create(Object obj)
        {
            NoteModel note = (NoteModel)obj;


            try
            {
                string request = "INSERT INTO note (id_note,id_noteuser_fk,title_note,comment_note) VALUES " +
                    "(@id_note, @id_noteuser_fk, @title_note, @comment_note)";

                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                command.Parameters.Add("@id_note", MySqlDbType.Int32);
                command.Parameters.Add("@id_noteuser_fk", MySqlDbType.Int32);
                command.Parameters.Add("@title_note", MySqlDbType.VarChar);
                command.Parameters.Add("@comment_note", MySqlDbType.VarChar);


                command.Parameters["@id_note"].Value = null;
                command.Parameters["@id_noteuser_fk"].Value = note.Id_noteuser_fk;
                command.Parameters["@title_note"].Value = note.Title_note;
                command.Parameters["@comment_note"].Value = note.Comment_note;


                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Note bien ajouté");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return note;
        }

        //Méthode DAO de suppression de note
        public override Object delete(Object obj)
        {
            NoteModel note = (NoteModel)obj;

            try
            {
                string request = "DELETE FROM note WHERE id_note =" + note.Id_note;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);

                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre note à bien été supprimé");
                dataReader.Close();

            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.ToString());
            }

            return note;
        }

        //Méthode DAO de modification de note
        public override Object update(Object obj)
        {
            NoteModel note = (NoteModel)obj;

            try
            {
                string request = "UPDATE note SET title_note = @New_title_note, comment_note = @New_comment_note" +
                    " WHERE id_note = " + note.Id_note;



                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);


                command.Parameters.Add("@New_title_note", MySqlDbType.VarChar);
                command.Parameters.Add("@New_comment_note", MySqlDbType.VarChar);


                command.Parameters["@New_title_note"].Value = note.Title_note;
                command.Parameters["@New_comment_note"].Value = note.Comment_note;


                MySqlDataReader dataReader = command.ExecuteReader();
                MessageBox.Show("Votre note a bien été modifiée");
                dataReader.Close();

            }
            catch (MySqlException exc)

            {
                MessageBox.Show(exc.ToString());
            }

            return note;
        }

        //Méthode DAO de recherche
        public override Object find(Object obj)
        {
            NoteModel note = (NoteModel)obj;
            UserModel user = new UserModel();
            try
            {
                string request = "SELECT * from note WHERE id_noteuser_fk = " + note.Id_noteuser_fk;
                MySqlCommand command = new MySqlCommand(request, this.Connect.Bdd);
                MySqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int id_note_reader = Convert.ToInt32(dataReader.GetValue(0));
                    string name_note_reader = dataReader.GetValue(2).ToString();
                    string comment_note_reader = dataReader.GetValue(3).ToString();
                    user.List_note.Add(new NoteModel() { Id_note = id_note_reader, Title_note = name_note_reader, Comment_note = comment_note_reader });
                }

                dataReader.Close();
            }
            catch (MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }
            return user.List_note;
        }




    }
}
