﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    //Objet Model de Note
    class NoteModel
    {
        //Attributs de NoteModel
        private int id_note;
        private int id_noteuser_fk;
        private string title_note;
        private string comment_note;

        //Constructeurs de NoteModel
        public NoteModel()
        {
            this.id_note = 0;
            this.id_noteuser_fk = 0;
            this.title_note = "";
            this.comment_note = "";
        }


        public NoteModel(int id_note, int id_noteuser_fk, string title_note, string comment_note)
        {
            this.id_note = id_note;
            this.id_noteuser_fk = id_noteuser_fk;
            this.title_note = title_note;
            this.comment_note = comment_note;
        }

        public NoteModel(int id_noteuser_fk, string title_note, string comment_note)
        {
            this.id_noteuser_fk = id_noteuser_fk;
            this.title_note = title_note;
            this.comment_note = comment_note;
        }

        public NoteModel(int id_noteuser_fk)
        {
            this.id_noteuser_fk = id_noteuser_fk;
        }

        public NoteModel(int id_note, int id_noteuser_fk)
        {
            this.id_note = id_note;
        }

        //Getter/Setter de NoteModel
        public int Id_note { get => id_note; set => id_note = value; }
        public int Id_noteuser_fk { get => id_noteuser_fk; set => id_noteuser_fk = value; }
        public string Title_note { get => title_note; set => title_note = value; }
        public string Comment_note { get => comment_note; set => comment_note = value; }
    }
}
