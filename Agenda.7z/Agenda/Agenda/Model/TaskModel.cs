﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    //Objet Model de Task
    class TaskModel
    {
        //Attributs de TaskModel
        private int id_task;
        private int id_taskuser_fk;
        private string name_task;
        private string comment_task;
        private string date_task;

        //Constructeurs de TaskModel
        public TaskModel()
        {
            this.id_task = 0;
            this.id_taskuser_fk = 0;
            this.name_task = "";
            this.comment_task = "";
            this.date_task = "";

        }


        public TaskModel(int id_task, int id_taskuser_fk, string name_task, string comment_task, string date_task)
        {
            this.id_task = id_task;
            this.id_taskuser_fk = id_taskuser_fk;
            this.name_task = name_task;
            this.comment_task = comment_task;
            this.date_task = date_task;
        }

        public TaskModel(int id_taskuser_fk, string name_task, string comment_task, string date_task)
        {
            this.id_taskuser_fk = id_taskuser_fk;
            this.name_task = name_task;
            this.comment_task = comment_task;
            this.date_task = date_task;
        }


        public TaskModel(int id_taskuser_fk)
        {
            this.id_taskuser_fk = id_taskuser_fk;
        }

        public TaskModel(int id_task, int id_taskuser_fk)
        {
            this.id_task = id_task;
        }

        //Getter/Setter
        public int Id_task { get => id_task; set => id_task = value; }
        public int Id_taskuser_fk { get => id_taskuser_fk; set => id_taskuser_fk = value; }
        public string Name_task { get => name_task; set => name_task = value; }
        public string Comment_task { get => comment_task; set => comment_task = value; }
        public string Date_task { get => date_task; set => date_task = value; }
    }
}
