﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    //Création unique d'un objet de connexion à la BDD
        sealed class ConnectionBdd
        {
        private string connectionString; 
        private static ConnectionBdd instance;
        private static int id_session;
        private MySqlConnection bdd;

        private ConnectionBdd()
        {
            connectionString = "Server=127.0.0.1;Database=bdd_agendatest;port=3306;User Id=root;password=";
            try
            {
                bdd = new MySqlConnection(connectionString);

                bdd.Open();
              
            }

            catch (MySql.Data.MySqlClient.MySqlException exc)
            {
                MessageBox.Show(exc.Message);
            }


        }

        public MySqlConnection Bdd { get => bdd; set => bdd = value; }
        public static int Id_session { get => id_session; set => id_session = value; }

        //Création d'un objet de la BDD si il est inexistante sinon renvoie a une instance existante de l'objet
        public static ConnectionBdd getInstance()
        {
            if (instance == null)
            {
                instance = new ConnectionBdd();
            }

            return instance;
        }
    }
}
